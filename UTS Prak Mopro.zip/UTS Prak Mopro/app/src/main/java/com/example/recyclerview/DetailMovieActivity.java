package com.example.recyclerview;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;


public class DetailMovieActivity extends AppCompatActivity {
    TextView tvNama;
    TextView tvHarga;
    TextView desc;
    ImageView imgView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_movie);
        setData();
    }
    public void setData(){
        imgView = findViewById(R.id.img_movie1);
        tvNama = findViewById(R.id.txt_name);
        tvHarga = findViewById(R.id.txt_harga);
        desc = findViewById(R.id.txt_deskripsil);

        tvNama.setText(getIntent().getStringExtra("nama"));
        tvHarga.setText(getIntent().getStringExtra("harga"));
        desc.setText(getIntent().getStringExtra("deskripsi"));
    }
}
