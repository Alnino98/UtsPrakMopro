package com.example.recyclerview;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import com.example.recyclerview.adapter.MovieAdapter;
import com.example.recyclerview.model.MovieModel;

import java.util.ArrayList;
import java.util.List;


public class MainActivity extends AppCompatActivity {
    MovieAdapter adapter;
    RecyclerView rv;
    int imgMovie = R.drawable.ayam;
    int gambar2 = R.drawable.undur;
    int gambar3 = R.drawable.monyet;
    int gambar4 = R.drawable.kuda;
    int gambar5 = R.drawable.laron;
    int gambar6 = R.drawable.kecoa;
    int gambar7 = R.drawable.kucing;
    int gambar8 = R.drawable.semut;

    List<MovieModel> listMovie = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initRecyclerView();
    }
    public void initRecyclerView(){
        adapter = new MovieAdapter(this);
        rv = findViewById(R.id.rv_movie);
        rv.setLayoutManager(new LinearLayoutManager(this));
        rv.setItemAnimator(new DefaultItemAnimator());
        rv.setAdapter(adapter);
        rv.setNestedScrollingEnabled(false);
        rv.hasFixedSize();
        adapter.setOnItemClickListener(new
                                               MovieAdapter.OnItemClickListener() {
                                                   @Override
                                                   public void onClick(int position) {
                                                       Intent i = new Intent(MainActivity.this,
                                                               DetailMovieActivity.class);

                                                       i.putExtra("name",listMovie.get(position).getName());
                                                       i.putExtra("harga",listMovie.get(position).getHarga());
                                                       i.putExtra("deskripsi",listMovie.get(position).getDesCription());
                                                       i.putExtra("gambar",listMovie.get(position).getGambar());
                                                       startActivity(i);
                                                   }
                                               });
        loadItem();
    }
    public void loadItem(){
        listMovie.add(new MovieModel("Nama : Ayam","Harga : Rp.2.700.000","Ayam Penuh Kenangan Walau sudah mati tetap dikenang", imgMovie));
        listMovie.add(new MovieModel("Nama : Semut","Harga : Rp.2.500.000","Semut Langka Walau kecil tetap kecil", R.drawable.semut));
        listMovie.add(new MovieModel("Nama : Undur","Harga : Rp.1.200.000","Undur dari tanah kubur penjaga kuburan", R.drawable.undur));
        listMovie.add(new MovieModel("Nama : Laron","Harga : Rp.5.400.000","Tetap ada walau gelap dan bersinar saat gelap", gambar5));
        listMovie.add(new MovieModel("Nama : Kecoa","Harga : Rp.11.500.000","Kecoa anti tempat kotor suka ditempat bersih", gambar6));
        listMovie.add(new MovieModel("Nama : Monyet","Harga : Rp.6.900.000","Moyet yang sering di katain monyet lu..!", gambar3));
        listMovie.add(new MovieModel("Nama : Kuda","Harga : Rp.9.450.000","Kuda paling cepat saat lari dengan tenaga 1000 lamborgini", gambar4));
        listMovie.add(new MovieModel("Nama : Kucing","Harga : Rp.8.750.000","Kucin Mencintai Hobynya Polygami", gambar7));
        adapter.addAll(listMovie);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.optionmenu, menu);
        //getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;

    }

    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId()==R.id.about){
            startActivity(new Intent(this, ProfileActivity.class));
        } else if (item.getItemId() == R.id.setting) {
            startActivity(new Intent(this, CangeActivity.class));
        }

        return true;
    }
}
