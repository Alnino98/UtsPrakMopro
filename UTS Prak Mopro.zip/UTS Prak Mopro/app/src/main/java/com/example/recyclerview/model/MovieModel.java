package com.example.recyclerview.model;

public class MovieModel {

    String name;
    String harga;
    String DesCription;
    int gambar;
    public MovieModel( String name, String harga, String
            desCription,int gambar) {
        this.name = name;
        this.harga = harga;
        this.DesCription = desCription;
        this.gambar = gambar;
    }

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getHarga() { return harga; }
    public void setHarga(String harga) {
        this.harga = harga;
    }
    public String getDesCription() {
        return DesCription;
    }
    public void setDesCription(String desCription) {
        DesCription = desCription;
    }
    public int getGambar() {
        return gambar;
    }
    public void setGambar(int Gambar) {
        this.gambar = gambar;
    }
}

